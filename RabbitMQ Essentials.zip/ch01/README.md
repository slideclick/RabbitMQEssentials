# RabbitMQ Essentials - Source Code

## Chapter 1

- `setup_rabbitmq.sh` : creates the vhost and users needed by the demos.
- `reset_rabbitmq.sh` : removes the vhost and users.


# RabbitMQ Essentials - Source Code

## Chapter 2

- Start the application simulator with: `mvn exec:java`,
- While it's running stop/restart the RabbitMQ broker to see the application reconnecting and recovering,
- Stop the application by striking `Enter`.

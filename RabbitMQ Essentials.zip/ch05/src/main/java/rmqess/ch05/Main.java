
package rmqess.ch05;

public class Main extends rmqess.ch03.Main
{
    public static void main(final String[] args) throws Exception
    {
        run(new UserMessageManager(), 13);
    }
}

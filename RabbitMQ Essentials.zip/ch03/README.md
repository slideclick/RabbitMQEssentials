# RabbitMQ Essentials - Source Code

## Chapter 3

### Java

- Start the application simulator with: `mvn exec:java`,
- Stop the application by striking `Enter`.

### Ruby

- Run: `bundle install`
- Then: `src/main/ruby/broadcast_to_all_users.rb` to send a test message to all users

